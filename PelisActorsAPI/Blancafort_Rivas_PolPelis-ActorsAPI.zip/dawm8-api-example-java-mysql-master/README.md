# dawm8-api-example-java-mysql
DAWM8 API example java mysql is an implementation of a N-M relationship between two entities courses and students.

## Run
 mvn clean package
 mvn embedded-glassfish:run

## Web
 http://localhost:8081/test/

## API v1
 http://localhost:8081/test/v1

### Students 
 http://localhost:8081/test/v1/students

### Courses
 http://localhost:8081/test/v1/courses
