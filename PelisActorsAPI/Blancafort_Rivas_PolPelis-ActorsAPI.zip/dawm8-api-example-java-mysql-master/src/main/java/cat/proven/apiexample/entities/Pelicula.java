package cat.proven.apiexample.entities;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Pelicula {

	private Integer id;
	private String nom;
	private int any;
	private List<Pelicula> pelicules;

	public Pelicula() {
		this.pelicules = new ArrayList<Pelicula>();
	}	

    public Pelicula(Integer id, String nom, int any) {
        this.id = id;
        this.nom = nom;
        this.any = any;
    }       

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getAny() {
        return any;
    }

    public void setAny(int any) {
        this.any = any;
    }

    public List<Pelicula> getPelicules() {
            return pelicules;
    }

    public void setPelicules(List<Pelicula> pelicules) {
            this.pelicules = pelicules;
    }
}
