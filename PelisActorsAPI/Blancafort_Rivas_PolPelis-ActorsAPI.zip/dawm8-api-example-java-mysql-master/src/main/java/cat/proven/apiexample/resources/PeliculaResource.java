package cat.proven.apiexample.resources;

import java.util.Collection;
import java.util.List;

import javax.servlet.ServletContext;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.GenericEntity;
import javax.ws.rs.core.Response;

import cat.proven.apiexample.dao.DAOFactory;
import cat.proven.apiexample.dao.ActorDAO;
import cat.proven.apiexample.entities.Actor;
import cat.proven.apiexample.entities.Pelicula;
import cat.proven.apiexample.exception.ApplicationException;
import cat.proven.apiexample.service.PeliculaService;


@Path("peliculas")
@Produces("application/json")
public class PeliculaResource {

    PeliculaService peliculaService;

    public PeliculaResource(@Context ServletContext context) {

        if (context.getAttribute("peliculaService") != null)
                peliculaService = (PeliculaService) context.getAttribute("peliculaService");
        else {
                peliculaService = new PeliculaService();
                context.setAttribute("peliculaService", peliculaService);
        }
    }

    @GET
    public Response peliculas() {
        Collection<Pelicula> peliculas = peliculaService.getPeliculas();
        GenericEntity<Collection<Pelicula>> result = new GenericEntity<Collection<Pelicula>>(peliculas) {
        };
        return Response.ok().entity(result).build();
    }

    @Path("{id}")
    @GET
    public Response getPeliculaById(@PathParam("id") int id) {
        Collection<Pelicula> peliculas = peliculaService.getPeliculas();
        GenericEntity<Collection<Pelicula>> result = new GenericEntity<Collection<Pelicula>>(peliculas) {
        };
        return Response.ok().entity(result).build();
    }

    @POST
    public Response addPelicula(@FormParam("name") String name, @FormParam("any") int any) {

        if (name == null || name.equals("")) {
            ApplicationException ex = new ApplicationException("Parameter name is mandatory");
            return Response.status(Response.Status.BAD_REQUEST).entity(ex).build();
        }

        Pelicula pelicula = peliculaService.addPelicula(new Pelicula(0, name, any));
        return Response.ok(pelicula).build();
    }

    @Path("{id}")
    @POST
    public Response updatePelicula(@FormParam("name") String name, @FormParam("any") int any, @PathParam("id") int id) {

        if (name == null || name.equals("")) {
                ApplicationException ex = new ApplicationException("Parameter name is mandatory");
                return Response.status(Response.Status.BAD_REQUEST).entity(ex).build();
        }

        Pelicula pelicula = peliculaService.getPeliculaById(id);

        if (pelicula == null)
                return Response.status(Response.Status.NOT_FOUND).build();

        pelicula.setNom(name);
        pelicula.setAny(any);
        pelicula = peliculaService.updatePelicula(pelicula);

        return Response.ok(pelicula).build();

    }

    @DELETE
    @Path("{id}")
    public Response deletePelicula(@PathParam("id") int id) {
        Pelicula pelicula = peliculaService.getPeliculaById(id);
        if (pelicula == null)
            return Response.status(Response.Status.NOT_FOUND).build();
        else {
            peliculaService.deletePelicula(pelicula);
            return Response.ok(pelicula).build();
        }
    }
}
