/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.proven.apiexample.dao;

import cat.proven.apiexample.entities.Actor;
import cat.proven.apiexample.entities.Pelicula;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

/**
 *
 * @author Blancafort
 */
public class PeliculaDAO {
    private Connection connection;

	public PeliculaDAO(Connection connection) {
		this.connection = connection;
	}
        
        public Connection getConnection() {
		return connection;
	}

	public Collection<Pelicula> findAll() {
            String sql = "SELECT * FROM Pelicula";
            ArrayList<Pelicula> list = new ArrayList<Pelicula>();

            try {
                PreparedStatement statement = getConnection().prepareStatement(sql);
                ResultSet rs = statement.executeQuery();

                while (rs.next()) {
                    Pelicula pelicula = new Pelicula(rs.getInt("id"), rs.getString("nom"), rs.getInt("any"));
                    list.add(pelicula);
                }
            } catch (Exception e) {
                    e.printStackTrace();
            }
            return list;
	}
        
        public Pelicula findById(int id) {
            String sql = "SELECT * FROM Pelicula WHERE id= ?";

            try {
                PreparedStatement statement = getConnection().prepareStatement(sql);

                statement.setInt(1, id);
                ResultSet rs = statement.executeQuery();

                while (rs.next()) {
                    Pelicula pelicula = new Pelicula(rs.getInt("id"), rs.getString("name"), rs.getInt("any") );
                    return pelicula;
                }

            } catch (SQLException e) {
                    e.printStackTrace();
            }
            return null;
	}
        
        public Pelicula add(Pelicula pelicula) {
            String sql = "INSERT INTO Pelicula (`id`, `name`, 'any') VALUES (NULL,?, ?)";

            try {
                PreparedStatement statement = getConnection().prepareStatement(sql);
                statement.setString(1, pelicula.getNom());
                statement.setInt(1, pelicula.getAny());
                int rs = statement.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
            return pelicula;
                
	}
        
        public Pelicula update(Pelicula pelicula) {
            String sql = "UPDATE Pelicula SET `name` = ? WHERE `Pelicula`.`id` = ?";

            try {
                PreparedStatement statement = getConnection().prepareStatement(sql);
                statement.setString(1, pelicula.getNom());
                statement.setInt(2, pelicula.getId());
                int rs = statement.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
            return pelicula;

	}

	public int delete(Pelicula pelicula) {
            String sql = "DELETE FROM Pelicula WHERE id = ?";
            int rs = 0;

            try {
                PreparedStatement statement = getConnection().prepareStatement(sql);
                statement.setInt(1, pelicula.getId());
                rs = statement.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
            return rs;
	}

}
