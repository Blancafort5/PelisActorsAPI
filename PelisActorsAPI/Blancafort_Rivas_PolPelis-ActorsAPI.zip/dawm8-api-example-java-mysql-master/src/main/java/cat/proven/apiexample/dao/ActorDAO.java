/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.proven.apiexample.dao;

import cat.proven.apiexample.entities.Actor;
import cat.proven.apiexample.entities.Pelicula;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

/**
 *
 * @author Blancafort
 */
public class ActorDAO {
    private Connection connection;

	public ActorDAO(Connection connection) {
		this.connection = connection;
	}
        
        public Connection getConnection() {
		return connection;
	}

	public Collection<Actor> findAll() {
            String sql = "SELECT * FROM Actor";
            ArrayList<Actor> list = new ArrayList<Actor>();

            try {
                PreparedStatement statement = getConnection().prepareStatement(sql);
                ResultSet rs = statement.executeQuery();

                while (rs.next()) {
                    Actor actor = new Actor(rs.getInt("id"), rs.getString("nom"), rs.getString("llocNaixement"), rs.getString("biografia"));
                    list.add(actor);
                }
            } catch (Exception e) {
                    e.printStackTrace();
            }
            return list;
	}
        
        public Actor findById(int id) {
            String sql = "SELECT * FROM Actor WHERE id= ?";

            try {
                PreparedStatement statement = getConnection().prepareStatement(sql);

                statement.setInt(1, id);
                ResultSet rs = statement.executeQuery();

                while (rs.next()) {
                    Actor actor = new Actor(rs.getInt("id"), rs.getString("name"), rs.getString("llocNaixement"), rs.getString("biografia") );
                    return actor;
                }

            } catch (SQLException e) {
                    e.printStackTrace();
            }
            return null;
	}
        
        public Actor add(Actor actor) {
            String sql = "INSERT INTO Actor (`id`, `name`, 'llocNaixement', 'biografia') VALUES (NULL,?, ?, ?)";

            try {
                PreparedStatement statement = getConnection().prepareStatement(sql);
                statement.setString(1, actor.getNom());
                statement.setString(1, actor.getLlocNaixement());
                statement.setString(1, actor.getBiografia());
                int rs = statement.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
            return actor;
                
	}
        
        public Actor update(Actor actor) {
            String sql = "UPDATE Actor SET `name` = ? WHERE `Actor`.`id` = ?";

            try {
                PreparedStatement statement = getConnection().prepareStatement(sql);
                statement.setString(1, actor.getNom());
                statement.setInt(2, actor.getId());
                int rs = statement.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
            return actor;

	}

	public int delete(Actor actor) {
            String sql = "DELETE FROM Actor WHERE id = ?";
            int rs = 0;

            try {
                PreparedStatement statement = getConnection().prepareStatement(sql);
                statement.setInt(1, actor.getId());
                rs = statement.executeUpdate();

            } catch (SQLException e) {
                e.printStackTrace();
            }
            return rs;
	}

}
