package cat.proven.apiexample.entities;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author AMS
 */
@XmlRootElement
public class Actor {
    private int id;
    private String nom;
    private String llocNaixement;
    private String biografia;
    private List<Actor> actors;

    public Actor() {
        this.actors = new ArrayList<Actor>();
    }

    public Actor(int id, String nom, String llocNaixement, String biografia) {
        this.id = id;
        this.nom = nom;
        this.llocNaixement = llocNaixement;
        this.biografia = biografia;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getLlocNaixement() {
        return llocNaixement;
    }

    public void getLlocNaixement(String llocNaixement) {
        this.llocNaixement = llocNaixement;
    }

    public String getBiografia() {
        return biografia;
    }

    public void setBiografia(String biografia) {
        this.biografia = biografia;
    }
    
    public List<Actor> getActors() {
            return actors;
    }

    public void setActors(List<Actor> actors) {
            this.actors = actors;
    }
}
