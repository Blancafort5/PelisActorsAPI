/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cat.proven.apiexample.service;

import cat.proven.apiexample.dao.PeliculaDAO;
import cat.proven.apiexample.dao.DAOFactory;

import cat.proven.apiexample.entities.Pelicula;
import cat.proven.apiexample.entities.Pelicula;

import java.util.Collection;

public class PeliculaService {
    
    public PeliculaDAO peliculaDAO;
    
    public PeliculaService () {
        peliculaDAO = DAOFactory.getInstance().createPeliculaDAO();
    }
    
    public Pelicula getPeliculaById(int idPelicula) {
        Pelicula c = peliculaDAO.findById(idPelicula);
        return c;
    }
   
    public Pelicula addPelicula(Pelicula pelicula) {
        Pelicula c = peliculaDAO.add(pelicula);
        return c;
    }
    
    public Pelicula updatePelicula(Pelicula pelicula) {
        Pelicula c = peliculaDAO.update(pelicula);
        return c;
    }
    
    public int deletePelicula(Pelicula pelicula) {
        int result = peliculaDAO.delete(pelicula);
        return result;
    }
    
    public Collection<Pelicula> getPeliculas() { 
        Collection<Pelicula> peliculas = peliculaDAO.findAll();
        return peliculas;
    }    
}
